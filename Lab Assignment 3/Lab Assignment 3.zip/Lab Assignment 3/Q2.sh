#!/bin/bash

# Question 2
# script to display disk usage of home directory and display it in human readable format.

# Display disk usage of home directory
du -sh ~
