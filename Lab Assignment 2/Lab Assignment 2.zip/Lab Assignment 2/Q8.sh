#!/bin/bash

# Question 8
# Program to find length of a string

echo "Enter a string: "
read str

echo "Length of the string is: ${#str}"